git clone https://github.com/GithubMOHAMMA/MMM

ls

cd MMM

python King-1.py
